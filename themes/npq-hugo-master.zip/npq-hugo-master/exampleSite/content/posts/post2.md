--- 
date: 2020-04-11T18:49:01+02:00
---

this is a micro blog used for short updates and link sharing, you can configure its behavior in config.toml